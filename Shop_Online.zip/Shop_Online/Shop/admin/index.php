<?php include('session.php'); ?>
<?php include('header.php'); ?>
<body>
<div id="wrapper">
<?php include('navbar.php'); ?>
<div style="height:50px;"></div>
<div id="page-wrapper">
<div class="container-fluid">
<div style="height:40px;"></div>
	<img src="../upload/cover.jpg" class="thumbnail" style="height:430px; width:1030px;">
</div>
</div>
</div>
<?php include('script.php'); ?>
<?php include('modal.php'); ?>
</body>
<div class="foot">
<footer>
<p> THIS PROJECT WAS MADE BY &copy;Andrei Necula in <?php echo date('Y');?> </p>
</footer>
<style> .foot{text-align: center; border: 2px solid black;}</style>
</div>
</html>
