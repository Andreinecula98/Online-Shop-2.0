<?php

$conn = mysqli_connect("localhost","root","","myshopdb");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
 
?>